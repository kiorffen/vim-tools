// +build ignore

package I1

import "fmt"

func example() {
	_ = fmt.Errorf("%s", "foo")
}
